package com.example.shubham.browser;

import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    EditText loc;
    EditText loc2;
    public boolean checkPermissionForReadExtertalStorage() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int result = getApplicationContext().checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE);
            return result == PackageManager.PERMISSION_GRANTED;
        }
        return false;
    }

    public void requestPermissionForReadExtertalStorage() throws Exception {
        try {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE},1);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button img=(Button)findViewById(R.id.imageview);
        Button del=(Button)findViewById(R.id.delete);
        Button ren=(Button)findViewById(R.id.rename);
        loc=(EditText)findViewById(R.id.loc);
        loc2=(EditText)findViewById(R.id.renloc);
        final ImageView img2= findViewById(R.id.img2);
        if(!checkPermissionForReadExtertalStorage())
        {
            try {
                requestPermissionForReadExtertalStorage();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        del.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

                File sdCard = Environment.getExternalStorageDirectory();
                Log.d("Location",""+sdCard);
                File directory = new File (sdCard.getAbsolutePath() + "/Pictures/Screenshots");
                Log.d("Location",""+directory);
                File file = new File(directory, loc.getText()+""); //or any other format supported

                if(file.exists()) {
                    file.delete();
                    Toast.makeText(MainActivity.this, "File " + loc.getText() + " is deleted ", Toast.LENGTH_LONG).show();
                }
                else
                    Toast.makeText(MainActivity.this,loc.getText()+" not found",Toast.LENGTH_LONG).show();


            }
        });

        ren.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

                File sdCard = Environment.getExternalStorageDirectory();
                Log.d("Location",""+sdCard);
                File directory = new File (sdCard.getAbsolutePath() + "/Pictures/Screenshots");
                Log.d("Location",""+directory);

                File file = new File(directory, loc.getText()+""); //or any other format supported
                File file2 = new File(directory, loc2.getText()+"");
                file.renameTo(file2);
                Toast.makeText(MainActivity.this,"File is renamed from "+loc.getText()+" to "+loc2.getText(),Toast.LENGTH_LONG).show();

            }
        });

        img.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

                File sdCard = Environment.getExternalStorageDirectory();
                Log.d("Location",""+sdCard);
                File directory = new File (sdCard.getAbsolutePath() + "/Pictures/Screenshots");
                Log.d("Location",""+directory);



                FileInputStream streamIn = null;
                try {
                    File file = new File(directory, loc.getText()+""); //or any other format supported
                    streamIn = new FileInputStream(file);
                    Log.d("Empty message",streamIn.toString());
                } catch (FileNotFoundException e) {
                    Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();
                }

                Bitmap bitmap = BitmapFactory.decodeStream(streamIn); //This gets the image
                img2.setImageBitmap(bitmap);

            }
        });



    }


}
