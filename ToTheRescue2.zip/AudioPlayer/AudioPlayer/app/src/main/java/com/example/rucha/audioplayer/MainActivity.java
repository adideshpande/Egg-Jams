package com.example.rucha.audioplayer;

import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity  {

    private String dataSource;
   private MediaPlayer mp;
   private int length;
   SeekBar seekBar;
    Handler handl = new Handler();
    Button bplay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        seekBar = (SeekBar)findViewById(R.id.seekBar);
       // seekBar.setOnSeekBarChangeListener(this);
        seekBar.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                touch(view);
                return false;
            }
        });
         bplay = findViewById(R.id.play1);
//        Button bpause = findViewById(R.id.pause1);
//        Button bstop = findViewById(R.id.stop1);
        mp = MediaPlayer.create(this,R.raw.shinchan);
        seekBar.setMax(mp.getDuration());
        //setDataSource("AudioPlayer\app\src\main\\res\\raw");

        bplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(bplay.getText().equals("Play")){
                mp.start();
                update();

                bplay.setText("Pause");

                }
                else
                {
                    mp.pause();
                    bplay.setText("Play");
                }
            }
        });




    }

    private void touch(View view) {
        if(mp.isPlaying())
        {
            SeekBar sb = (SeekBar)view;
            mp.seekTo(sb.getProgress());
        }
    }

    //
    public void update() {
        seekBar.setProgress(mp.getCurrentPosition());
        if (mp.isPlaying()) {
            Runnable run = new Runnable() {

                @Override
                public void run() {
                    update();
                }
            };
            handl.postDelayed(run, 1000);
        }
        else
        {
            mp.pause();
            bplay.setText("Play");
        }
    }



}
