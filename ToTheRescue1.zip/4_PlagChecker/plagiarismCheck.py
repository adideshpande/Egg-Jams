from bottle import route, run, template, post, request
from collections import Counter
import math

'''
COSINE SIMILARITY  for vectors A & B = ( A dot B ) / |A||B|

numerator = A dot B
		  = a1*b1 + a2*b2 + ... + aN*bN

denominator = |A||B|
			= sqrt[ a1*a1 + a2*a2 + ... aN*aN ] * sqrt[ b1*b1 + b2*b2 + ... + bN*bN ]	 
			 
'''

@route('/')
def index():
    return template('indexPlagChecker.html')

@post('/')
def plagChecker():
	
	#get query
    query = request.forms.get("txtbox")
    
    #pre-processing to query contents
    query = query.replace("+"," ")
    query = query.strip()
    query = query.replace("\r\n"," ")
    query = query.replace("\t"," ")
    query = query.lower()
    print "\nQuery: ", query					#query contents as is
    
    queryS = query.split(" ")
    print "\nQueryS: ", queryS					#query contents split into array of words
    
    #get doc
    Doc = open("doc.txt","r")
    DocLines = Doc.readlines()
    DocLines = ''.join(DocLines)
    
    #pre-processing to doc contents
    DocLines = DocLines.lower()
    DocLines = DocLines.replace("\r\n"," ")
    DocLines = DocLines.replace("\t"," ")
    print "\nDocLines: ", DocLines				#document contents as is
    
    DocS = DocLines.split(" ")
    print "\nDocS: ", DocS						#document contents split into array of words

    termFreqDoc = dict(Counter(DocS))			#count how many times a term occurs in the text and arrange it in alphabetic form
    print "\nCounter(DocS): ", Counter(DocS)
    print "\ntermFreqDoc: ", termFreqDoc

    termFreqQ = dict(Counter(queryS))
    print "\nCounter(queryS): ", Counter(queryS)
    print "\ntermFreqQ: ", termFreqQ

    f1 = {}
    f2 = {}
    for word in termFreqDoc:
        if word in termFreqQ:
            f1[word] = termFreqDoc[word]*termFreqQ[word]	#if a word occurs in both doc (x times) and in query (y times) then assign it value x*y
        else:
            f1[word] = 0

    print "\nf1: ",f1

    for word in termFreqQ:
        if word in termFreqDoc:
            f2[word] = termFreqDoc[word]*termFreqQ[word]	#if a word occurs in both doc (x times) and in query (y times) then assign it value x*y
        else:
            f2[word] = 0

    print "\nf2: ",f2

    f1.update(f2)		#adds f2 terms to f1 
    print "\nafter update f1: ",f1
	#now f1 has dot product of doc and query in array form ie [a1*b1, a2*b2, a3*b3, ... aN*bN]
    
    numerator = 0
    for i in f1:
        numerator += f1[i]

    print "\n\nNumerator",numerator
	
    denominator = 0
    dSum = 0
    for i in termFreqDoc:
        dSum += termFreqDoc[i]*termFreqDoc[i]
    sumSqrtDoc = math.sqrt(dSum)

    dSum = 0
    for i in termFreqQ:
        dSum += termFreqQ[i]*termFreqQ[i]
    sumSqrtQ = math.sqrt(dSum)

    denominator = sumSqrtDoc*sumSqrtQ

    print "\n\n\nCosine Similarity",(numerator/denominator)
    
    return "This document is ",str(round(numerator/denominator,4)*100),"% plagiarised!"
    
    
    
run(host='localhost',posrt=8080, debug=True)
