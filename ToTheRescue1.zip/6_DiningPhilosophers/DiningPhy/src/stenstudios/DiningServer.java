package stenstudios;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class DiningServer {

	static DiningServer server;
	ServerSocket serverSocket;
	ExecutorService executorService = Executors.newFixedThreadPool(5);
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		server = new DiningServer();
		server.runServer();

	}
	
	void runServer() {
		int port = 12345;
		
		System.out.println("Starting Server");
		try {
			serverSocket = new ServerSocket(port);
			
			System.out.println("Server Running");
			while(true) {
				Socket s = serverSocket.accept();
				executorService.submit(new ServiceRequest(s));
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	void stopServer() {
		executorService.shutdown();
		
		try {
			serverSocket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

class ServiceRequest implements Runnable{
	
	Socket socket;
	ServiceRequest(Socket connection){
		this.socket = connection;
	}

	public void run() {
		// TODO Auto-generated method stub
		OutputStream ostream;
		DataOutputStream dout = null;
		try {
			
			MongoClient mongoClient = new MongoClient();
			
			MongoDatabase db = mongoClient.getDatabase("testdb");
			MongoCollection<Document> collection = db.getCollection("testcollection");
			
			InputStream istream = socket.getInputStream();
			ostream = socket.getOutputStream();
			dout = new DataOutputStream(ostream);
			DataInputStream din = new DataInputStream(istream);
			//BufferedReader bRead = new BufferedReader(new InputStreamReader(istream));
			
			int pId = din.readInt(); 
			//String pId = "1";
			System.out.println("Hello from Philosopher "+pId);
			
			Document document = new Document("eid",pId)
					.append("name", "java")
					.append("address", "mum");
			
			collection.insertOne(document);
			
			dout.writeBytes("1");
			mongoClient.close();
			
			//bRead.close();
			socket.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			try {
				dout.writeBytes("0");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			
		}
	}
	
}
