package stenstudios;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.concurrent.Semaphore;

public class DiningClient {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Semaphore sem = new Semaphore(5);
		
		PhilosopherEats[] pe = new PhilosopherEats[5];
		
		for(int i=0;i<5;i++) {
			pe[i] = new PhilosopherEats(sem, i+1);
		}
		
		
		try {
			System.out.println("Philosopher 1 wants to eat");
			pe[0].start();
			Thread.sleep(1000);
			
			System.out.println("Philosopher 2 wants to eat");
			pe[1].start();
			Thread.sleep(4000);
			
			System.out.println("Philosopher 3 wants to eat");
			pe[2].start();
			Thread.sleep(1000);
			
			System.out.println("Philosopher 4 wants to eat");
			pe[3].start();
			Thread.sleep(3000);
			
			System.out.println("Philosopher 5 wants to eat");
			pe[4].start();
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			
	}
	

}

class PhilosopherEats extends Thread{
	
	private int pId;
	Semaphore sem;
	
	PhilosopherEats(Semaphore sem, int pId){
		this.pId = pId;
		this.sem = sem;
	}
	
	public void run() {
try {
			sem.acquire(2);
			System.out.println("Philosopher "+pId+" is Eating");
			Socket s = new Socket("localhost",12345);
			InputStream istream = s.getInputStream();
			OutputStream ostream = s.getOutputStream();
			DataOutputStream dout = new DataOutputStream(ostream);
			BufferedReader bRead = new BufferedReader(new InputStreamReader(istream));
			//dout.writeBytes(String.valueOf(pId));
			dout.writeInt(pId);
			
			if(bRead.readLine().toString().contentEquals("1")) {
				System.out.println("Database updated");
			}
			else {
				System.out.println("Error in database");
			}
			
			dout.close();
			s.close();
			sem.release(2);
			System.out.println("Philosopher "+pId+" is Thinking");
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
