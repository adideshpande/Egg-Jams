
def binarysearch( arr, l, r, key ):

	if r >= l:
		
		mid = l + (r-l)/2
		
		if arr[mid] == key:
			return mid
			
		elif arr[mid] > key:
			return binarysearch( arr, l, mid-1, key)
		
		elif arr[mid] < key:
			return binarysearch( arr, mid+1, r, key)
					
	else:
		return -1
		
		
def sort( arr, n ):

	for i in range (0, n):
	
		for j in range (0, n-i-1):
	
			if arr[j] > arr[j+1] :
               
				arr[j], arr[j+1] = arr[j+1], arr[j]
				
	return arr
			
 
if __name__ == '__main__':
	
	arr = [] 
	i = 0
	
	print "\nEnter the size of the array: "
	n = int(input())
	
	print "\nEnter the array elements in unsorted manner: "
	
	while i<n:
		arr.append(int(input()))
		i+=1
		
		
	arr = sort(arr, n)
	print "The sorted array is: ", arr	
	
	answer = 'y'
	while str(answer) == 'y':
	
		print "\nEnter the element to be searched: "
		key = int(input())
	
		result = binarysearch( arr, 0, n-1, key )
	
		if result == -1:
			print "Element not found in array"
		
		else:
			print "Element found at location: ", result+1
		
		print "Do you want to continue? [ y / n ] : "
		answer = raw_input()
	
