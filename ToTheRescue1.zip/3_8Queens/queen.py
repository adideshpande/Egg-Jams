import json

def isattack(board,r,c):		#returns true if "r"th queen cannot be legally placed in "c"th column 
    
    for i in range(r):			#check if "c"th column is already occupied by any queen
        if(board[i][c]==1):		
            return True
    
    i=r-1		
    j=c-1	
    while((i>=0) and (j>=0)):	#check if "\" diagonal elements are present
        if(board[i][j]==1):
            return True	
        i=i-1
        j=j-1
    
    i=r-1
    j=c+1	
    while((i>=0) and (j<8)):	#check if "/" diagonal elements are present
        if(board[i][j]==1):
            return True
        i=i-1
        j=j+1
    
    return False				#if queen is not being attacked by any other queen return false
    

def solve(board,row):			#1 function call places the "row"th queen
    i=0
    
    while(i<8):					#for all columns 0 to 7 check if queen can be placed
        if(not isattack(board, row, i)):	#whichever column is free
            board[row][i]=1					#place the queen
            
            if(row==7):				#if its last queen then function returns true as all queens have been placed successfully
                return True	
            else:					#if its not the last queen 
                if(solve(board, row+1)):	#check if next queen can be placed legally
                    return True	
                else:				#if the next queen cannot be placed
                    board[row][i]=0	#BACKTRACK
        i=i+1
    
    if(i==8):						#if last queen is also unable to be placed then solution is not found so return false
        return False
    
def printboard(board):
    for i in range(8):
        for j in range(8):
            print str(board[i][j])+"  ",
        print "\n"
        
board = [[0 for x in range(8)] for x in range(8)]

if __name__ == '__main__':
    
    data=[]
    with open('input.json') as f:
        data=json.load(f)
    
    if(data["start"]<0 or data["start"]>7):
        print "Invalid JSON input"
        exit()
    
    board[0][data["start"]]=1		#place 1st queen in user specified column and 0th row
    if(solve(board, 1)):			#call board function on 1st row ie for 2nd queen 
        print "Queens problem solved!!!"	#if it returns true then solution found
        print "Board Configuration:"
        printboard(board)
    else:							#if solve function returns false then solution not found
        print "Queens problem not solved!!!"
    
