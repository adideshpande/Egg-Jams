from bottle import route, run, template, post, request

AQ = []
M = []
MC = []

@route('/')                         #localhost:8080/
def index():                        #implicit call when we type the above addr on browser
    return template('index.html')

@post('/')
def readNums():
    m_minus=0                       #Complement
    q_minus=0
    postdata= request.body.read()   #html-body read
    print (postdata)
    m = request.forms.get("m")      
    q = request.forms.get("q")
    if(int(m)<0):                   #absolute value for negative input
        m=int(int(m)*-1)
        m_minus=1
    if(int(q)<0):
        q=int(int(q)*-1)
        q_minus=1

    global AQ,M,MC
    A = [0,0,0,0]
    AQ = []
    M = []
    Q = []
    MC = []

    binM = "{0:04b}".format(int(m)) #binary representation in 4 bits
    for i in binM:
            M.append(int(i))

    print("M:",M)
    
    MC=complement(M,3)              #MC - M's Complement
    print("MC:",MC)
        
    binQ = "{0:04b}".format(int(q))
    for i in binQ:
            Q.append(int(i))
    print("Q:",Q)

    
    if m_minus==1:                  #Swap M,MC if m is neg
        M,MC=MC,M
    if q_minus==1:                  #2's complement of Q if q is neg
        Q=complement(Q,3)
    Q.append(0)                     # Q-1

    AQ = A + Q                      #+ for append

    print("AQ:",AQ)

    for i in range(len(M)):
            if(AQ[7]==AQ[8]):
                    shift()
                    print("S :",AQ)
            elif(AQ[7:]==[0,1]):
                    add()
                    print("Add :",AQ)
                    shift()
                    print("S :",AQ)
            else:
                    sub()
                    print("Sub :",AQ)
                    shift()
                    print("S :",AQ)

    AQ=AQ[:len(AQ)-1]                   #Q-1 removed
    print("AQ:",AQ)
    comp = ''.join(str(e) for e in AQ)  #coverting AQ integer array to string
    print(AQ)
    if(AQ[0])==1:                       #if ans is neq, take complement
        AQ=complement(AQ,7)
    print(AQ)

    binary = ''.join(str(e) for e in AQ) #coverting AQ integer array to string
    print(binary)
    
    if(m_minus^q_minus)==1:
        return "Result:<br> In Decimal: -{0} <br> In Binary: {1}".format(int(binary,2), comp)
    return "Result:<br> In Decimal: {0} <br> In Binary: {1}".format(int(binary,2), binary)

def complement(arr,n):
    arr_com=[]
    for i in arr:                       #Complement
        if int(i)==0:
                    arr_com.append(1)
        else:
                    arr_com.append(0)
    c=1                                #2's Complement
    for i in range(n,-1,-1): 
        arr_com[i] = arr_com[i] + c
        if arr_com[i]==2:
            arr_com[i] = 0
            c=1
        else:
            c=0
    return(arr_com)

def shift():
    global AQ
    AQ = AQ[:len(AQ)-1]
    AQ.insert(0,AQ[0])

def add():
    global AQ
    c=0
    for i in range(3,-1,-1):      
        AQ[i] = AQ[i] + M[i] + c
        if AQ[i]==3:
            AQ[i]=1
            c=1
        elif AQ[i]==2:
            AQ[i] = 0
            c=1
        else:
            c=0

def sub():
    global AQ
    c=0
    for i in range(3,-1,-1):
        AQ[i] = AQ[i] + MC[i] + c
        if AQ[i]==3:
            AQ[i]=1
            c=1
        elif AQ[i]==2:
            AQ[i] = 0
            c=1
        else:
            c=0

run(host='localhost', port=8080)

